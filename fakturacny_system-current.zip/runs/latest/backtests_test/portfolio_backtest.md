# Portfolio Backtest Report

- Symbols: 1
- Rows: 12
- Avg equity end: 1.008663
- Fee bps: 2.00
- Slippage bps: 3.00
- Funding bps: 0.00
- Profit target net: 0.0200

## Per Symbol

| Symbol | Trades | Equity End | Profit-Gate Hit Ratio |
|---|---:|---:|---:|
| UNKNOWN | 12 | 1.008663 | 0.0000 |
